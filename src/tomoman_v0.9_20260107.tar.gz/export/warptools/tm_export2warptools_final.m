function tm_export2warptools_final(tomolist, export)


%% create a particle list

% read motl and wedgelist
if exist(export.sg_motl,'file')
    motl = sg_motl_read(export.sg_motl);
else
    error('Motl not found!!!');
end

particlestar_name = [export.output_dir,'/particles.star'];
apix = tomolist(1).pixelsize;

tm_sgmotl2warptools(motl, tomolist, particlestar_name, apix)
disp('Export finished!!!')

%% Initialize Warptools project
script_name = [export.output_dir,'/initialize_warptools.sh'];
fid = fopen(script_name,'w');

% Create bash file 

fprintf(fid,['#!/usr/bin/env bash \n\n','set -e \n','set -o nounset \n\n']);
fprintf(fid,'# Initializing WarpTools project \n\n');

fprintf(fid,'# Create frameseries settings \n\n');
fprintf(fid,['WarpTools create_settings --folder_data tilts --folder_processing warp_frameseries --output warp_frameseries.settings --extension "*.mrc" --angpix ' num2str(apix) ' --exposure ' num2str(export.pertilt_exposure) '\n\n']);

fprintf(fid,'# Run per tilt CTF estimation \n\n');
fprintf(fid,['WarpTools fs_ctf --settings warp_frameseries.settings --grid 2x2x1 --range_max 5 --range_min 40 --use_sum\n\n']);

fprintf(fid,'# Link tilt images \n\n');
fprintf(fid,['ln -sf ' export.output_dir '/tilts/*.mrc warp_frameseries/ \n\n']);
fprintf(fid,['mkdir ' export.output_dir '/warp_frameseries/average \n\n']);
fprintf(fid,['ln -sf ' export.output_dir '/tilts/*.mrc ' export.output_dir '/warp_frameseries/average/\n\n']);

fprintf(fid,'# Make sure everything is selected \n\n');
fprintf(fid,['WarpTools change_selection --settings warp_frameseries.settings --select\n\n']);

fprintf(fid,'# Import tilt series metadata from pseudo mdoc files \n\n');
fprintf(fid,['WarpTools ts_import --mdocs mdocs --frameseries warp_frameseries --tilt_exposure ' num2str(export.pertilt_exposure) ' --output tomostar\n\n']);

fprintf(fid,'# Create tiltseries settings \n\n');
fprintf(fid,['WarpTools create_settings --output warp_tiltseries.settings --folder_processing warp_tiltseries --folder_data tomostar --extension "*.tomostar" --angpix ' num2str(apix) ' --exposure ' num2str(export.pertilt_exposure) ' --tomo_dimensions ' num2str(export.tomodim(1)) 'x' num2str(export.tomodim(2)) 'x' num2str(export.tomodim(3)) '\n\n']);

fprintf(fid,'# Import tilt series alignments \n\n');
fprintf(fid,['WarpTools ts_import_alignments --settings warp_tiltseries.settings --alignments imod --alignment_angpix ' num2str(apix) '\n\n']);

fprintf(fid,'# Check defocus handedness \n\n');
fprintf(fid,['WarpTools ts_defocus_hand --settings warp_tiltseries.settings --check\n\n']);

fprintf(fid,'# Perform CTF estimation for tilt series \n\n');
fprintf(fid,['WarpTools ts_ctf --settings warp_tiltseries.settings --range_high 5 --defocus_max 5 \n\n']);

fprintf(fid,'# Reconstruct Tomograms for visualisation OR debugging \n\n');
fprintf(fid,['WarpTools ts_reconstruct --settings warp_tiltseries.settings --angpix ' num2str(apix.*8) '\n\n']);

fprintf(fid,'# Export Particles \n\n');
fprintf(fid,['mkdir ' export.output_dir '/relion \n\n']);
fprintf(fid,['WarpTools ts_export_particles --settings warp_tiltseries.settings --input_star particles.star --output_star relion/warptools.star --output_angpix ' num2str(apix.*export.particle_bin) ' --coords_angpix ' num2str(apix) ' --box ' num2str(export.particle_box) ' --diameter ' num2str(export.particle_radii) ' --relative_output_paths --3d \n\n']);

fclose(fid);

% Run script
system(['chmod +x ',script_name]);
%system(script_name);


end

